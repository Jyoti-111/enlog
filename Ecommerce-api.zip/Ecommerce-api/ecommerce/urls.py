from rest_framework import generics, status, permissions, viewsets
from rest_framework.response import Response
from rest_framework.decorators import action
from django.core.cache import cache
from django.db.models import Sum
from .models import User, Category, Product, Order, OrderItem
from .serializers import (
    RegisterSerializer, UserSerializer,
    ProductSerializer, CategorySerializer,
    OrderSerializer, OrderItemSerializer
)

# User Registration View
class RegisterView(generics.CreateAPIView):
    queryset = User.objects.all()
    serializer_class = RegisterSerializer

# Profile View
class ProfileView(generics.RetrieveUpdateAPIView):
    permission_classes = [permissions.IsAuthenticated]
    serializer_class = UserSerializer

    def get_object(self):
        return self.request.user

# Category ViewSet (Admin only)
class CategoryViewSet(viewsets.ModelViewSet):
    queryset = Category.objects.all()
    serializer_class = CategorySerializer
    permission_classes = [permissions.IsAdminUser]

# Product ViewSet
class ProductViewSet(viewsets.ModelViewSet):
    queryset = Product.objects.select_related('category').all()
    serializer_class = ProductSerializer

    def list(self, request, *args, **kwargs):
        cache_key = 'product_list'
        cached_data = cache.get(cache_key)
        if cached_data:
            return Response(cached_data)

        queryset = self.filter_queryset(self.get_queryset())

        # Filtering
        category = request.GET.get('category')
        price_min = request.GET.get('price_min')
        price_max = request.GET.get('price_max')
        in_stock = request.GET.get('in_stock')

        if category:
            queryset = queryset.filter(category__id=category)
        if price_min:
            queryset = queryset.filter(price__gte=price_min)
        if price_max:
            queryset = queryset.filter(price__lte=price_max)
        if in_stock == 'true':
            queryset = queryset.filter(stock__gt=0)

        page = self.paginate_queryset(queryset)
        if page is not None:
            serializer = self.get_serializer(page, many=True)
            cache.set(cache_key, serializer.data, timeout=3600)
            return self.get_paginated_response(serializer.data)

        serializer = self.get_serializer(queryset, many=True)
        cache.set(cache_key, serializer.data, timeout=3600)
        return Response(serializer.data)

    def perform_update(self, serializer):
        serializer.save()
        cache.delete('product_list')

    def perform_destroy(self, instance):
        instance.delete()
        cache.delete('product_list')

# Order View
class OrderViewSet(viewsets.ModelViewSet):
    queryset = Order.objects.prefetch_related('orderitem_set__product').all()
    serializer_class = OrderSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        if self.request.user.is_staff:
            return Order.objects.all()
        return self.queryset.filter(user=self.request.user)

    def create(self, request):
        user = request.user
        items = request.data.get('items', [])  # list of {product_id, quantity}
        if not items:
            return Response({'detail': 'No items provided'}, status=400)

        total_price = 0
        order = Order.objects.create(user=user)

        for item in items:
            product = Product.objects.get(id=item['product_id'])
            quantity = item['quantity']
            if product.stock < quantity:
                order.delete()
                return Response({'detail': f'Not enough stock for {product.name}'}, status=400)
            OrderItem.objects.create(order=order, product=product, quantity=quantity)
            product.stock -= quantity
            product.save()
            total_price += product.price * quantity

        order.total_price = total_price
        order.save()

        # Clear cache
        cache.delete('product_list')

        return Response(OrderSerializer(order).data, status=201)
