from django.test import TestCase

# TODO: Write tests for user, product, order creation
